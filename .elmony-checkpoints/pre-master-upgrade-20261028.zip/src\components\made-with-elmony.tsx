export const MadeWithElmony = () => {
  return (
    <div className="p-4 text-center">
      <a
        href="https://www.elmony.com/"
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
      >
        Made with Elmony
      </a>
    </div>
  );
};
